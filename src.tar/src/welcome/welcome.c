#include "apilib.h"
#include <string.h>
void HariMain(void)
{
	int win;
	char s[32], * p;
	api_cmdline(s, 30);
	for (p = s; *p > ' '; p++) {}	/*一直读到空格为止*/
	for (; *p == ';'; p++) {}	/*跳过空格*/
	
	char buf[220 * 100];
	win = api_openwin(buf, 220, 100, -1, "Error");
	
	if (*p == 0) {
		p = "Invalid or corrupt file.";
	}
	api_putstrwin(win, 10, 28, 7 /*黑色*/, strlen(p), p);
	for (;;) {
		if (api_getkey(1) == 0x0a) {
			break; /*exit */
		}
	}
	api_end();
}
