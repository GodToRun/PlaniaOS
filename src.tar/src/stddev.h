#pragma once
#include "apilib.h"
#include "stdlib.h"
#define MAX_MEMORY 0x100000000; //4.24GB
#define MIN_MEMORY 0x400000; //4MB
#define STD_NULL 0
#define start HariMain

typedef struct {
	int winid;
	int wincolor;
	int size_x;
	int size_y;
	char* buffer;
	char* title;
} STD_WINDOW;
typedef struct {
	int x, y;
} STD_POINT;
typedef enum {
	BLACK = 0,
	RED = 1,
	GREEN = 2,
	YELLOW = 3,
	LIGHTCYAN = 4,
	PINK = 5,
	LIGHTBLUE = 6,
	WHITE = 7,
	DARKGRAY = 8,
	BROWN = 9,
	LIGHTGREEN = 10,
	LIGHTCYAN1 = 11,
	BLUE = 12,
	PURPLE = 13,
	CYAN = 14,
	LIGHTGRAY = 15
} WinColor;
//Create Window
STD_WINDOW CreateWindow(char* _title, int _size_x, int _size_y) {
	STD_WINDOW retwin;
	retwin.title = _title;
	retwin.size_x = _size_x;
	retwin.size_y = _size_y;
	retwin.wincolor = BLACK;
	char* __buf;
	api_initmalloc();
	__buf = malloc(_size_x * _size_y);
	//__buf = api_malloc(_size_x * _size_y);
	retwin.buffer = __buf;
	retwin.winid = api_openwin(__buf, _size_x, _size_y, -1, _title);
	return retwin;
}
void ExitWindow() {
	api_end();
}
void DrawFilledRectangle(STD_WINDOW stdwin, int _x, int _y, int _width, int _height) {
	api_boxfilwin(stdwin.winid, _x, _y, _x + _width, _y + _height, stdwin.wincolor);
}
void DrawString(STD_WINDOW stdwin, char* _str, int _x, int _y) {
	api_putstrwin(stdwin.winid, _x, _y, stdwin.wincolor, (int)strlen(_str), _str);
}
void Close(STD_WINDOW stdwin) {
	api_closewin(stdwin.winid);
}
void DrawChar(char _ch) {
	api_putchar((int)_ch);
}
void DrawLine(STD_WINDOW window, int x0, int y0, int x1, int y1) {
	api_linewin(window.winid, x0, y0, x1, y1, window.wincolor);
}
