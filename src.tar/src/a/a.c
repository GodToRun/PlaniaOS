#include "../apilib.h"
#include "../stdlib.h"
void HariMain(void)
{
	for (;;) {
		int key = api_getkey(1);
		printf("%c", (char)key);
	}
	api_end();
}
