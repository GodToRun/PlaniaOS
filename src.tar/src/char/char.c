#include "apilib.h"
#include "../stddev.h"
#include <string.h>
#include <stdio.h>
void start(void)
{
	char *buf;
	int win,r,g,b,x,y;
	//api_initmalloc();
	//buf = api_malloc(144 * 164);
	//win = api_openwin(buf, 144, 164, -1, "File Manager");
	STD_WINDOW strwin = CreateWindow("Characters",144,164);
	win = strwin.winid;
	buf = strwin.buffer;
	/*for (y = 0; y < 128; y++) {
		for (x = 0; x < 128; x++) {
			r = x * 2;
			g = y * 2;
			b = 0;
			buf[(x + 8) + (y + 28) * 144] = 16 + (r / 43) + (g / 43) * 6 + (b / 43) * 36;
		}
	}*/
	int _i;
	int _x = 0;
	int _y = 20;
	char* cp;
	
	for ( _i = 0; _i < 128; _i++) {
		sprintf(cp, "%c", (char)_i);
		DrawString(strwin, cp, _x, _y);
		_x += 5;
		if (_x > 70) {
			_x = 0;
			_y += 20;
		}
	}
	api_getkey(1);
	ExitWindow();
}
