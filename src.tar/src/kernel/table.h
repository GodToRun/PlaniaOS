// Plania OS Table
#include <stdlib.h>
#define LIMIT 1000
#define ROW_MAX 1000
#define COLUMN_MAX 1000
struct ITEM {
	void* value;
};
void insert_item(struct TABLE* table, int row, int column, struct ITEM* item) {
	table->item_table[row][column] = item;
}
void drop_table(struct TABLE* table) {
	table = (struct TABLE*)0;
}
void delete_item(struct TABLE* table, int row, int column) {
	table->item_table[row][column] = (struct ITEM *)0
}
struct TABLE {
	char* name;
	struct ITEM* item_table[ROW_MAX][COLUMN_MAX] = { {0} };
};
struct TABLE* tables[LIMIT] = { {0} };