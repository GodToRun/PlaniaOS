#define BITMAP_SIZE 16
struct BITMAP {
	char bits[BITMAP_SIZE][BITMAP_SIZE];
};