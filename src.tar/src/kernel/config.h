struct CONFIG {
	void *data;
};

void *read_config(struct CONFIG *con) {
	return con->data;
}