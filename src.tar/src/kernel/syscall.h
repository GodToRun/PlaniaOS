#include "task.h"
#include "bootpack.h"
#include "ramdisk.h"
#define TRUE 0
#define FALSE 1
#define NULL 0
struct RAMDISK *syscall_ramdisk(struct MEMMAN *memman) {
	struct RAMDISK* disk = cramdsk(memman);
	return disk;
	return (struct RAMDISK *)NULL;
}