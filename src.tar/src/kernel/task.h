#include <string.h>
struct APPTASK {
	struct APPINFO* info;
	int PID;
	char* taskname;
};
struct APPINFO {
	char* publisher;
};
void put_task(struct APPTASK* task);
void end_task(int index);
int end_tasks(char* pname);
struct APPTASK* get_task(int i);
struct APPTASK* get_tasks(char* pname);
int task_cur = 0;
struct APPTASK* tasklist[1000] = { {0} };
void end_task(int index) {
	tasklist[index]->taskname = '\0';
	tasklist[index] = (struct APPTASK*)0;
	task_cur--;
}
void put_task(struct APPTASK* task) {
	tasklist[task_cur] = task;
	task_cur++;
}
int end_tasks(char* pname) {
	int i;
	for (i = 0; i < task_cur+1; i++) {
		struct APPTASK* task = tasklist[i];
		if (strcmp(task->taskname, pname) == 0) {
			end_task(i);
			return 0;
		}
	}
	return -1;
}
struct APPTASK* get_tasks(char* pname) {
	int i;
	for (i = 0; i < task_cur; i++) {
		struct APPTASK* task = tasklist[i];
		if (strcmp(task->taskname, pname) == 0) {
			return task;
		}
	}
}
struct APPTASK* get_task(int i) {
	struct APPTASK* task = tasklist[i];
	return task;
}