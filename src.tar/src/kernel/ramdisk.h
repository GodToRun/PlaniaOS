#include <string.h>
#define NULL (void *)0
#define FSIZE_LIMIT 512 //512Byte
struct RAMDISK {
	int cur;
	struct RAMFILE *files[32]; //16KB
};
struct RAMFILE {
	char name[8];
	char ext[3];
	int size;
	char bytes[FSIZE_LIMIT];
};
int diskcur = 0;
struct RAMDISK* disklist[4];
void format(struct RAMDISK *disk) {
	disk->cur = 0;
}
void delete(struct MEMMAN *memman, struct RAMDISK *disk) {
	disklist[diskcur] = NULL;
	diskcur--;
	memman_free(memman, disk, sizeof(struct RAMDISK));
}
struct RAMDISK *cramdsk(struct MEMMAN *memman) {
	struct RAMDISK* disk = memman_alloc(memman, sizeof(struct RAMDISK));
	disklist[diskcur] = disk;
	diskcur++;
	format(disk);
	return disk;
}
char *read_rfile(struct RAMFILE *file) {
	return file->bytes;
}
void write_rfile(struct RAMFILE *file, char *buf, int size) {
	file->size = size;
	strcpy(file->bytes, buf);
}
void append_rfile(struct RAMFILE *file, char *buf, int bufsize) {
	file->size += bufsize;
	char bytes[512];
	strcpy(bytes, file->bytes);
	sprintf(file->bytes, "%s%s", bytes, buf);
}
struct RAMFILE *create_rfile(struct RAMDISK* disk, char filename[8], char ext[3], int size) {
	struct RAMFILE* file;
	file->size = size;
	strcpy(file->name, filename);
	strcpy(file->ext, ext);
	disk->files[disk->cur] = file;
	disk->cur++;
	return file;
}