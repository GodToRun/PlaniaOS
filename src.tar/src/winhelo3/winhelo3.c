#include "apilib.h"
#include "../apilib.h"
#include "../widget.h"
#include "../stddev.h"
#include <string.h>
#include <stdio.h>
void start(void)
{
	STD_WINDOW win;
	win = CreateWindow("Hello",200,200);
	win.wincolor = WHITE;
	//api_boxfilwin(win.winid,  8, 36, 141, 43, 6); /*浅蓝色*/
	//api_putstrwin(win, 28, 28, 0 , 12, "hello, world");/*黑色*/
	int cur = 5;
	for (;;) {
		int key = api_getkey(1);
		char* text;
		sprintf(text, "%c", (char)key);
		DrawString(win,text,cur,20);
		cur += 15;
	}
	ExitWindow();
}