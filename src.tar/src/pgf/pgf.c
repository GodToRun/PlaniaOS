#include "apilib.h"
#include "../stddev.h"
#include <string.h>

int DrawMap(STD_WINDOW _win, int __x, int __y) {
	api_boxfilwin(_win.winid, 4, 24, 345, 275, LIGHTGRAY); //BG
	_win.wincolor = BLACK;
	DrawFilledRectangle(_win, __x + 50, __y + 60, 40, 30);
	return 0;
}
void HariMain(void)
{
	//char *buf;
	int win, i, x, y;
	//api_initmalloc();
	//buf = api_malloc(160 * 100);
	//win = api_openwin(buf, 160, 100, -1, "Game");
	STD_WINDOW strwin = CreateWindow("PGF Adventure", 350, 280);
	win = strwin.winid;
	x = 76;
	y = 56;
	for (;;) {
		i = api_getkey(1);
		if (i == '4') { x += 8; }
		if (i == '6') { x -= 8; }
		if (i == '8') { y += 8; }
		if (i == '2') { y -= 8; }
		if (i == 0x0a) { break; }
		DrawMap(strwin, x, y);
		strwin.wincolor = 7;
		DrawString(strwin, "O", 150, 110); //Character
	}
	api_closewin(win);
	api_end();
}

